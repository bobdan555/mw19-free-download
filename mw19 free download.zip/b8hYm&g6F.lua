-- Define the RGB values for the color silver
local targetColor = {192, 192, 192}

-- Function to get the color of a pixel at the specified coordinates
function getPixelColor(x, y)
    local color = ahk.pixelGetColor(x, y)
    return {math.floor(color / 0x10000), math.floor(color / 0x100) % 0x100, color % 0x100}
end

-- Function to check if a color matches the target color
function colorMatch(color1, color2)
    return color1[1] == color2[1] and color1[2] == color2[2] and color1[3] == color2[3]
end

-- Function to scan the screen for the target color and move the mouse to it
function findAndMoveToColor(targetColor)
    local screenWidth, screenHeight = ahk.getScreenResolution()

    for y = 0, screenHeight - 1 do
        for x = 0, screenWidth - 1 do
            local pixelColor = getPixelColor(x, y)
            if colorMatch(pixelColor, targetColor) then
                ahk.mouseMove(x, y)
                return true
            end
        end
    end
    return false
end

-- Execute the function to find the silver color and move the mouse to it
if not findAndMoveToColor(targetColor) then
    ahk.showMessage("Silver color not found on the screen.")
end
